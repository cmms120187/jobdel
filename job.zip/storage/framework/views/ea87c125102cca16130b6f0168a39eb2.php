<?php
    use Illuminate\Support\Facades\Storage;
?>

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                <?php echo e(__('Detail Delegasi')); ?>

            </h2>
            <a href="<?php echo e(route('delegations.index', ['page' => session('delegations_page', 1)])); ?>" class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded text-sm">
                Kembali
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-4xl mx-auto sm:px-6 lg:px-8">
            <?php if(session('success')): ?>
                <div class="mb-4 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative" role="alert">
                    <span class="block sm:inline"><?php echo e(session('success')); ?></span>
                </div>
            <?php endif; ?>

            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <!-- Main Content -->
                <div class="lg:col-span-2">
                    <!-- Task Info -->
                    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
                        <div class="p-6">
                            <h1 class="text-2xl font-bold text-gray-900 mb-2">
                                <a href="<?php echo e(route('tasks.show', $delegation->task)); ?>" class="text-blue-600 hover:text-blue-800">
                                    <?php echo e($delegation->task->title); ?>

                                </a>
                            </h1>
                            <p class="text-gray-600 mb-4"><?php echo e($delegation->task->description); ?></p>
                            <div class="flex gap-2">
                                <span class="px-3 py-1 text-sm rounded <?php echo e($delegation->status === 'completed' ? 'bg-green-100 text-green-800' : ($delegation->status === 'accepted' || $delegation->status === 'in_progress' ? 'bg-blue-100 text-blue-800' : 'bg-yellow-100 text-yellow-800')); ?>">
                                    <?php echo e(ucfirst($delegation->status)); ?>

                                </span>
                                <span class="px-3 py-1 text-sm rounded <?php echo e($delegation->task->priority === 'high' ? 'bg-red-100 text-red-800' : ($delegation->task->priority === 'medium' ? 'bg-yellow-100 text-yellow-800' : 'bg-gray-100 text-gray-800')); ?>">
                                    <?php echo e(ucfirst($delegation->task->priority)); ?>

                                </span>
                            </div>
                        </div>
                    </div>

                    <!-- Delegation Info -->
                    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
                        <div class="p-6">
                            <h2 class="text-lg font-semibold text-gray-900 mb-4">Informasi Delegasi</h2>
                            <div class="grid grid-cols-2 gap-4 text-sm">
                                <div>
                                    <span class="font-semibold text-gray-700">Delegasikan ke:</span>
                                    <p class="text-gray-600">
                                        <?php echo e($delegation->delegatedTo->name); ?>

                                        <?php if($delegation->delegatedTo->position): ?>
                                            <span class="text-xs text-gray-500">(<?php echo e($delegation->delegatedTo->position->name); ?>)</span>
                                        <?php endif; ?>
                                    </p>
                                </div>
                                <div>
                                    <span class="font-semibold text-gray-700">Delegasikan oleh:</span>
                                    <p class="text-gray-600">
                                        <?php echo e($delegation->delegatedBy->name); ?>

                                        <?php if($delegation->delegatedBy->position): ?>
                                            <span class="text-xs text-gray-500">(<?php echo e($delegation->delegatedBy->position->name); ?>)</span>
                                        <?php endif; ?>
                                    </p>
                                </div>
                                <div>
                                    <span class="font-semibold text-gray-700">Progress:</span>
                                    <p class="text-gray-600"><?php echo e($delegation->progress_percentage); ?>%</p>
                                </div>
                                <?php if($delegation->accepted_at): ?>
                                    <div>
                                        <span class="font-semibold text-gray-700">Diterima pada:</span>
                                        <p class="text-gray-600"><?php echo e($delegation->accepted_at->format('d M Y H:i')); ?></p>
                                    </div>
                                <?php endif; ?>
                                <?php if($delegation->completed_at): ?>
                                    <div>
                                        <span class="font-semibold text-gray-700">Selesai pada:</span>
                                        <p class="text-gray-600"><?php echo e($delegation->completed_at->format('d M Y H:i')); ?></p>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <?php if($delegation->notes): ?>
                                <div class="mt-4">
                                    <span class="font-semibold text-gray-700">Catatan:</span>
                                    <p class="text-gray-600 mt-1"><?php echo e($delegation->notes); ?></p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Task Items Progress -->
                    <?php if($delegation->task->taskItems->count() > 0): ?>
                        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
                            <div class="p-6">
                                <div class="flex justify-between items-center mb-4">
                                    <h2 class="text-lg font-semibold text-gray-900">Detail Pekerjaan Task</h2>
                                    <a href="<?php echo e(route('tasks.show', $delegation->task)); ?>" class="text-blue-600 hover:text-blue-800 text-sm font-medium">
                                        Lihat Detail Task →
                                    </a>
                                </div>
                                <?php
                                    // Get task items assigned to this delegation user only
                                    $userTaskItems = $delegation->task->taskItems->where('assigned_to', $delegation->delegated_to);
                                    $userProgress = 0;
                                    if ($userTaskItems->isNotEmpty()) {
                                        $totalProgress = $userTaskItems->sum('progress_percentage');
                                        $userProgress = round($totalProgress / $userTaskItems->count());
                                    }
                                ?>
                                <div class="mb-4">
                                    <div class="flex items-center gap-2 mb-2">
                                        <span class="text-sm font-semibold text-gray-700">Progress Anda:</span>
                                        <span class="text-lg font-bold text-blue-600"><?php echo e($userProgress); ?>%</span>
                                    </div>
                                    <div class="w-full bg-gray-200 rounded-full h-3">
                                        <div class="bg-gradient-to-r from-blue-600 to-indigo-600 h-3 rounded-full transition-all" style="width: <?php echo e($userProgress); ?>%"></div>
                                    </div>
                                    <p class="text-xs text-gray-500 mt-1">Progress berdasarkan detail pekerjaan yang di-assign ke Anda</p>
                                    <?php if($userTaskItems->isEmpty()): ?>
                                        <p class="text-xs text-orange-600 mt-2 font-medium">
                                            ⚠️ Belum ada detail pekerjaan yang di-assign ke Anda. Delegasi tetap pending sampai Anda mulai bekerja.
                                        </p>
                                    <?php endif; ?>
                                </div>
                                <div class="space-y-3 max-h-96 overflow-y-auto">
                                    <?php if($userTaskItems->isEmpty()): ?>
                                        <div class="text-center py-4 text-gray-500">
                                            <p class="text-sm">Belum ada detail pekerjaan yang di-assign ke Anda.</p>
                                            <p class="text-xs mt-1">Klik "Lihat Detail Task" di atas untuk melihat semua detail pekerjaan.</p>
                                        </div>
                                    <?php endif; ?>
                                    <?php $__currentLoopData = $userTaskItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="border rounded-lg p-3 bg-gray-50">
                                            <div class="flex justify-between items-start mb-2">
                                                <div class="flex-1">
                                                    <h4 class="font-semibold text-sm text-gray-900"><?php echo e($item->title); ?></h4>
                                                    <?php if($item->description): ?>
                                                        <p class="text-xs text-gray-600 mt-1"><?php echo e(Str::limit($item->description, 100)); ?></p>
                                                    <?php endif; ?>
                                                </div>
                                                <span class="px-2 py-1 text-xs rounded ml-2 <?php echo e($item->status === 'completed' ? 'bg-green-100 text-green-800' : ($item->status === 'in_progress' ? 'bg-blue-100 text-blue-800' : 'bg-yellow-100 text-yellow-800')); ?>">
                                                    <?php echo e(ucfirst(str_replace('_', ' ', $item->status))); ?>

                                                </span>
                                            </div>
                                            <div class="mt-2">
                                                <div class="flex items-center gap-2 mb-1">
                                                    <div class="flex-1 bg-gray-200 rounded-full h-2">
                                                        <div class="bg-blue-600 h-2 rounded-full transition-all" style="width: <?php echo e($item->progress_percentage); ?>%"></div>
                                                    </div>
                                                    <span class="text-xs font-semibold text-gray-700 w-12 text-right"><?php echo e($item->progress_percentage); ?>%</span>
                                                </div>
                                                <?php if($item->assignedUser && $item->assignedUser->id == $delegation->delegated_to): ?>
                                                    <p class="text-xs text-gray-500 mt-1">Assigned to: <?php echo e($item->assignedUser->name); ?></p>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="mt-4 pt-4 border-t">
                                    <p class="text-xs text-gray-500">
                                        <strong>Catatan:</strong> Progress delegation ini terupdate otomatis berdasarkan progress detail pekerjaan yang di-assign ke Anda. 
                                        Delegasi tetap <strong>pending</strong> sampai Anda mulai update progress pada detail pekerjaan yang di-assign ke Anda.
                                        Untuk update detail pekerjaan, klik "Lihat Detail Task" di atas.
                                    </p>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <!-- Progress Updates -->
                    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                        <div class="p-6">
                            <h2 class="text-lg font-semibold text-gray-900 mb-4">Update Progress</h2>
                            
                            <?php if($delegation->delegated_to === auth()->id() && $delegation->status !== 'completed'): ?>
                                <form method="POST" action="<?php echo e(route('progress.store', $delegation)); ?>" enctype="multipart/form-data" class="mb-6">
                                    <?php echo csrf_field(); ?>
                                    <div class="mb-4">
                                        <?php if (isset($component)) { $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-label','data' => ['for' => 'progress_percentage','value' => __('Progress (%)')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'progress_percentage','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Progress (%)'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $attributes = $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $component = $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>
                                        <?php if (isset($component)) { $__componentOriginal18c21970322f9e5c938bc954620c12bb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal18c21970322f9e5c938bc954620c12bb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.text-input','data' => ['id' => 'progress_percentage','class' => 'block mt-1 w-full','type' => 'number','name' => 'progress_percentage','min' => '0','max' => '100','value' => old('progress_percentage', $delegation->progress_percentage),'required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'progress_percentage','class' => 'block mt-1 w-full','type' => 'number','name' => 'progress_percentage','min' => '0','max' => '100','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('progress_percentage', $delegation->progress_percentage)),'required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal18c21970322f9e5c938bc954620c12bb)): ?>
<?php $attributes = $__attributesOriginal18c21970322f9e5c938bc954620c12bb; ?>
<?php unset($__attributesOriginal18c21970322f9e5c938bc954620c12bb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal18c21970322f9e5c938bc954620c12bb)): ?>
<?php $component = $__componentOriginal18c21970322f9e5c938bc954620c12bb; ?>
<?php unset($__componentOriginal18c21970322f9e5c938bc954620c12bb); ?>
<?php endif; ?>
                                        <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('progress_percentage'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('progress_percentage')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                                        <p class="mt-1 text-xs text-gray-500">Masukkan persentase progress (0-100%)</p>
                                    </div>
                                    <div class="mb-4">
                                        <?php if (isset($component)) { $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-label','data' => ['for' => 'notes','value' => __('Catatan / Laporan')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'notes','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Catatan / Laporan'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $attributes = $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $component = $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>
                                        <textarea id="notes" name="notes" rows="4" class="block mt-1 w-full border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm" placeholder="Jelaskan perkembangan task..."><?php echo e(old('notes')); ?></textarea>
                                        <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('notes'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('notes')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                                    </div>
                                    <div class="mb-4">
                                        <?php if (isset($component)) { $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-label','data' => ['for' => 'photos','value' => __('Upload Photo Bukti (Opsional - bisa pilih multiple)')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'photos','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Upload Photo Bukti (Opsional - bisa pilih multiple)'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $attributes = $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $component = $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>
                                        <input id="photos" name="photos[]" type="file" multiple accept="image/*" class="block mt-1 w-full border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100">
                                        <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('photos'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('photos')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                                        <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('photos.*'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('photos.*')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                                        <p class="mt-1 text-xs text-gray-500">Maksimal 5MB per foto. Format: JPG, PNG, GIF</p>
                                    </div>
                                    <?php if (isset($component)) { $__componentOriginald411d1792bd6cc877d687758b753742c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald411d1792bd6cc877d687758b753742c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => ['class' => 'w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full']); ?>
                                        <svg class="w-5 h-5 inline mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"></path>
                                        </svg>
                                        <?php echo e(__('Update Progress')); ?>

                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $attributes = $__attributesOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__attributesOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $component = $__componentOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__componentOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
                                </form>
                            <?php endif; ?>

                            <?php if($delegation->progressUpdates->count() > 0): ?>
                                <div class="space-y-6">
                                    <?php $__currentLoopData = $delegation->progressUpdates->sortByDesc('created_at'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $update): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="bg-gray-50 rounded-lg p-4 border-l-4 border-blue-500">
                                            <div class="flex justify-between items-start mb-3">
                                                <div class="flex-1">
                                                    <div class="flex items-center gap-3 mb-2">
                                                        <span class="text-2xl font-bold text-blue-600"><?php echo e($update->progress_percentage); ?>%</span>
                                                        <div class="flex-1 bg-gray-200 rounded-full h-3">
                                                            <div class="bg-blue-600 h-3 rounded-full transition-all" style="width: <?php echo e($update->progress_percentage); ?>%"></div>
                                                        </div>
                                                    </div>
                                                    <p class="text-sm text-gray-500 mb-2">
                                                        <span class="font-semibold"><?php echo e($update->updater->name); ?></span>
                                                        <?php if($update->updater->position): ?>
                                                            <span class="text-xs">(<?php echo e($update->updater->position->name); ?>)</span>
                                                        <?php endif; ?>
                                                        <span class="text-gray-400">•</span>
                                                        <span><?php echo e($update->created_at->format('d M Y, H:i')); ?></span>
                                                    </p>
                                                    <?php if($update->notes): ?>
                                                        <p class="text-gray-700 mt-2 whitespace-pre-wrap bg-white p-3 rounded border"><?php echo e($update->notes); ?></p>
                                                    <?php endif; ?>
                                                    
                                                    <?php if($update->attachments && count($update->attachments) > 0): ?>
                                                        <div class="mt-3">
                                                            <p class="text-sm font-semibold text-gray-700 mb-2">Photo Bukti:</p>
                                                            <div class="grid grid-cols-2 md:grid-cols-3 gap-3">
                                                                <?php $__currentLoopData = $update->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <div class="relative group">
                                                                        <a href="<?php echo e(route('progress.download-file', ['progressUpdate' => $update->id, 'index' => $i])); ?>" target="_blank" class="block">
                                                                            <img src="<?php echo e(route('progress.download-file', ['progressUpdate' => $update->id, 'index' => $i])); ?>" alt="Bukti progress" class="w-full h-32 object-cover rounded-lg border-2 border-gray-200 hover:border-blue-500 transition-all cursor-pointer">
                                                                        </a>
                                                                        <a href="<?php echo e(route('progress.download-file', ['progressUpdate' => $update->id, 'index' => $i])); ?>" target="_blank" class="absolute inset-0 flex items-center justify-center bg-black bg-opacity-0 group-hover:bg-opacity-50 transition-all rounded-lg">
                                                                            <svg class="w-8 h-8 text-white opacity-0 group-hover:opacity-100 transition-opacity" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v3m0 0v3m0-3h3m-3 0H7"></path>
                                                                            </svg>
                                                                        </a>
                                                                    </div>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </div>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php else: ?>
                                <div class="text-center py-8 bg-gray-50 rounded-lg">
                                    <svg class="w-12 h-12 text-gray-400 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path>
                                    </svg>
                                    <p class="text-gray-500">Belum ada update progress.</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Sidebar -->
                <div>
                    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                        <div class="p-6">
                            <h3 class="font-semibold text-gray-900 mb-4">Actions</h3>
                            <?php if($delegation->delegated_to === auth()->id()): ?>
                                <?php if($delegation->status === 'pending'): ?>
                                    <form method="POST" action="<?php echo e(route('delegations.update', $delegation)); ?>" class="mb-2">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <input type="hidden" name="action" value="accept">
                                        <button type="submit" class="w-full bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded text-sm mb-2">
                                            Terima Delegasi
                                        </button>
                                    </form>
                                    <form method="POST" action="<?php echo e(route('delegations.update', $delegation)); ?>" class="mb-2">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <input type="hidden" name="action" value="reject">
                                        <button type="submit" class="w-full bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded text-sm mb-2">
                                            Tolak Delegasi
                                        </button>
                                    </form>
                                <?php endif; ?>
                                <?php if($delegation->status === 'accepted' || $delegation->status === 'in_progress'): ?>
                                    <form method="POST" action="<?php echo e(route('delegations.update', $delegation)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <input type="hidden" name="action" value="complete">
                                        <button type="submit" class="w-full bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded text-sm">
                                            Tandai Selesai
                                        </button>
                                    </form>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>

<?php /**PATH C:\xampp\htdocs\training\job-delegation\resources\views/delegations/show.blade.php ENDPATH**/ ?>