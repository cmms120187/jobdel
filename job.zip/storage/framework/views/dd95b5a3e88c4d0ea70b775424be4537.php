

<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto py-8 px-4">
    <h1 class="text-2xl font-semibold mb-4">Bawahan Saya</h1>

    <p class="text-sm text-gray-600 mb-6">Daftar bawahan termasuk bawahan bawahan (rekursif). Klik nama untuk melihat profil.</p>

    <?php if($subordinates->isEmpty()): ?>
        <div class="bg-white p-4 rounded shadow">Anda tidak memiliki bawahan.</div>
    <?php else: ?>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <?php $__currentLoopData = $subordinates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('leader.subordinates.show', $sub->id)); ?>" class="block bg-white hover:shadow-lg transition-shadow p-4 rounded">
                    <div class="flex items-center">
                        <div class="w-12 h-12 rounded-full bg-gradient-to-br from-yellow-400 to-pink-500 text-white font-bold flex items-center justify-center me-4"><?php echo e(strtoupper(substr($sub->name,0,1))); ?></div>
                        <div>
                            <div class="font-semibold"><?php echo e($sub->name); ?></div>
                            <div class="text-sm text-gray-500"><?php echo e(optional($sub->position)->name ?? '—'); ?></div>
                        </div>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\training\job-delegation\resources\views/leader/subordinates/index.blade.php ENDPATH**/ ?>