

<?php $__env->startSection('content'); ?>
<div class="max-w-6xl mx-auto py-8 px-4">
    <div class="flex items-center justify-between mb-4">
        <h1 class="text-2xl font-semibold">Daftar Tugas Tim</h1>
        <div class="flex items-center space-x-2">
            <form method="GET" class="flex items-center space-x-2">
                <input type="text" name="q" value="<?php echo e(request('q')); ?>" placeholder="Cari judul, kode, pembuat" class="rounded border px-3 py-1" />
                <select name="status" class="rounded border px-2 py-1">
                    <option value="">Semua status</option>
                    <?php $__currentLoopData = ['pending','in_progress','completed','cancelled']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($s); ?>" <?php echo e(request('status')==$s ? 'selected' : ''); ?>><?php echo e(str_replace('_',' ', $s)); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <input type="date" name="start_date" value="<?php echo e(request('start_date')); ?>" class="rounded border px-2 py-1" />
                <input type="date" name="end_date" value="<?php echo e(request('end_date')); ?>" class="rounded border px-2 py-1" />
                <button class="px-3 py-1 bg-purple-600 text-white rounded">Filter</button>
            </form>
            <a href="<?php echo e(route('leader.reports.export', request()->query())); ?>" class="px-3 py-1 bg-gray-100 rounded border">Export CSV</a>
        </div>
    </div>

    <div class="bg-white rounded shadow overflow-hidden">
        <table class="min-w-full">
            <thead class="bg-gray-50">
                <tr>
                    <th class="p-3 text-left">ID</th>
                    <th class="p-3 text-left">Project</th>
                    <th class="p-3 text-left">Title</th>
                    <th class="p-3 text-left">Creator</th>
                    <th class="p-3 text-left">Status</th>
                    <th class="p-3 text-left">Priority</th>
                    <th class="p-3 text-left">Created At</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-t">
                        <td class="p-3"><?php echo e($task->id); ?></td>
                        <td class="p-3"><?php echo e($task->project_code); ?></td>
                        <td class="p-3"><a href="<?php echo e(route('tasks.show', $task)); ?>" class="text-blue-600"><?php echo e($task->title); ?></a></td>
                        <td class="p-3"><?php echo e(optional($task->creator)->name); ?></td>
                        <td class="p-3 capitalize"><?php echo e(str_replace('_',' ', $task->status)); ?></td>
                        <td class="p-3"><?php echo e($task->priority); ?></td>
                        <td class="p-3"><?php echo e(optional($task->created_at)->format('Y-m-d H:i')); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        <?php echo e($tasks->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\training\job-delegation\resources\views/leader/reports/tasks.blade.php ENDPATH**/ ?>