

<?php $__env->startSection('content'); ?>
<div class="max-w-5xl mx-auto py-8 px-4">
    <h1 class="text-2xl font-semibold mb-4">Laporan Ringkas Tim</h1>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div class="bg-white p-4 rounded shadow">
            <h2 class="font-semibold">Tim (termasuk saya)</h2>
            <div class="mt-3">
                <div class="text-4xl font-bold"><?php echo e($teamTotal); ?></div>
                <div class="text-sm text-gray-500">Total tugas dibuat oleh tim Anda</div>
                <div class="mt-4 text-sm text-gray-600">Periode: <strong><?php echo e($start); ?></strong> sampai <strong><?php echo e($end); ?></strong></div>

                <div class="mt-6 flex items-center space-x-3">
                    <a href="<?php echo e(route('leader.subordinates.index')); ?>" class="inline-flex items-center px-4 py-2 bg-purple-600 text-white rounded">Lihat Bawahan</a>
                    <a href="<?php echo e(route('leader.reports.tasks', ['start_date'=>$start, 'end_date'=>$end])); ?>" class="inline-flex items-center px-4 py-2 bg-gray-100 rounded border">Lihat Tugas</a>
                </div>
            </div>
            <div class="mt-4">
                <h3 class="font-medium">Status</h3>
                <ul class="mt-2 space-y-1">
                    <?php $__currentLoopData = ['pending','in_progress','completed','cancelled']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="flex justify-between">
                                <span class="capitalize"><?php echo e(str_replace('_', ' ', $s)); ?></span>
                                <a href="<?php echo e(route('leader.reports.tasks', ['status' => $s])); ?>" class="font-medium"><?php echo e($teamCounts->get($s, 0)); ?></a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>

                            <div class="mt-8 bg-white p-4 rounded shadow">
                                <h3 class="font-semibold mb-2">Visualisasi Status</h3>
                                <div class="flex items-center justify-between mb-2">
                                    <div></div>
                                    <button id="downloadChartBtn" class="inline-flex items-center px-3 py-1 bg-indigo-600 text-white rounded text-sm">Download Chart PNG</button>
                                </div>
                                <canvas id="statusChart" height="140"></canvas>
                            </div>

                                <?php $__env->startPush('scripts'); ?>
                                <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
                                <script>
                                    (function(){
                                        const ctx = document.getElementById('statusChart').getContext('2d');
                                        const labels = <?php echo json_encode($statusOrder); ?>.map(s => s.replace('_', ' '));

                                        // create gradient for team
                                        const teamGrad = ctx.createLinearGradient(0,0,0,200);
                                        teamGrad.addColorStop(0, 'rgba(99,102,241,0.95)');
                                        teamGrad.addColorStop(1, 'rgba(99,102,241,0.6)');

                                        const selfGrad = ctx.createLinearGradient(0,0,0,200);
                                        selfGrad.addColorStop(0, 'rgba(16,185,129,0.95)');
                                        selfGrad.addColorStop(1, 'rgba(16,185,129,0.6)');

                                        const data = {
                                            labels,
                                            datasets: [
                                                {
                                                    label: 'Tim',
                                                    data: <?php echo json_encode($teamData); ?>,
                                                    backgroundColor: teamGrad,
                                                    borderRadius: 6,
                                                    barThickness: 28
                                                },
                                                {
                                                    label: 'Saya',
                                                    data: <?php echo json_encode($selfData); ?>,
                                                    backgroundColor: selfGrad,
                                                    borderRadius: 6,
                                                    barThickness: 18
                                                }
                                            ]
                                        };

                                        const statusChart = new Chart(ctx, {
                                            type: 'bar',
                                            data: data,
                                            options: {
                                                responsive: true,
                                                plugins: {
                                                    legend: { position: 'top' },
                                                    title: { display: true, text: 'Distribusi status tugas (bulan berjalan)' }
                                                },
                                                scales: {
                                                    x: { stacked: false },
                                                    y: { beginAtZero: true, ticks: { precision:0 } }
                                                },
                                                interaction: { mode: 'index', intersect: false }
                                            }
                                        });

                                        // download button
                                        const dlBtn = document.getElementById('downloadChartBtn');
                                        const filename = <?php echo json_encode("status_chart_{$start}_to_{$end}.png"); ?>;
                                        dlBtn.addEventListener('click', function(){
                                            const canvas = document.getElementById('statusChart');
                                            if (canvas.toBlob) {
                                                canvas.toBlob(function(blob){
                                                    const url = URL.createObjectURL(blob);
                                                    const a = document.createElement('a');
                                                    a.href = url;
                                                    a.download = filename;
                                                    document.body.appendChild(a);
                                                    a.click();
                                                    a.remove();
                                                    URL.revokeObjectURL(url);
                                                }, 'image/png');
                                            } else {
                                                const url = canvas.toDataURL('image/png');
                                                const a = document.createElement('a');
                                                a.href = url;
                                                a.download = filename;
                                                document.body.appendChild(a);
                                                a.click();
                                                a.remove();
                                            }
                                        });
                                    })();
                                </script>
                                <?php $__env->stopPush(); ?>

                            <?php $__env->startPush('scripts'); ?>
                            <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
                            <script>
                                (function(){
                                    const ctx = document.getElementById('statusChart').getContext('2d');
                                    const labels = <?php echo json_encode($statusOrder); ?>.map(s => s.replace('_', ' '));
                                    const data = {
                                        labels,
                                        datasets: [
                                            {
                                                label: 'Tim',
                                                data: <?php echo json_encode($teamData); ?>,
                                                backgroundColor: 'rgba(99, 102, 241, 0.8)'
                                            },
                                            {
                                                label: 'Saya',
                                                data: <?php echo json_encode($selfData); ?>,
                                                backgroundColor: 'rgba(16, 185, 129, 0.8)'
                                            }
                                        ]
                                    };

                                    new Chart(ctx, {
                                        type: 'bar',
                                        data: data,
                                        options: {
                                            responsive: true,
                                            scales: {
                                                x: { stacked: false },
                                                y: { beginAtZero: true }
                                            }
                                        }
                                    });
                                })();
                            </script>
                            <?php $__env->stopPush(); ?>

        <div class="bg-white p-4 rounded shadow">
            <h2 class="font-semibold">Saya</h2>
            <div class="mt-3">
                <div class="text-4xl font-bold"><?php echo e($selfTotal); ?></div>
                <div class="text-sm text-gray-500">Total tugas yang saya buat</div>
            </div>
            <div class="mt-4">
                <h3 class="font-medium">Status</h3>
                <ul class="mt-2 space-y-1">
                    <?php $__currentLoopData = ['pending','in_progress','completed','cancelled']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="flex justify-between">
                                <span class="capitalize"><?php echo e(str_replace('_', ' ', $s)); ?></span>
                                <a href="<?php echo e(route('leader.reports.tasks', ['status' => $s, 'q' => null])); ?>" class="font-medium"><?php echo e($selfCounts->get($s, 0)); ?></a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </div>

    <div class="mt-6">
        <a href="<?php echo e(route('leader.subordinates.index')); ?>" class="inline-flex items-center px-4 py-2 bg-purple-600 text-white rounded">Lihat Bawahan</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\training\job-delegation\resources\views/leader/reports/overview.blade.php ENDPATH**/ ?>