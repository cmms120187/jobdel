<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center justify-between">
            <div class="flex items-center">
                <div class="w-12 h-12 gradient-blue rounded-lg flex items-center justify-center mr-4">
                    <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                </div>
                <div>
                    <h2 class="font-bold text-2xl text-gray-800 leading-tight">
                        <?php echo e(__('Laporan Waktu Kerja Tim')); ?>

                    </h2>
                    <p class="text-sm text-gray-500 mt-1">Tracking waktu kerja tim Anda per hari</p>
                </div>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-4 sm:py-8 bg-gradient-to-br from-gray-50 via-blue-50 to-purple-50 min-h-screen">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <!-- Filter Section -->
            <div class="bg-white rounded-xl shadow-lg p-6 mb-6">
                <form method="GET" action="<?php echo e(route('leader.reports.work-time')); ?>" class="flex flex-col sm:flex-row gap-4 items-end">
                    <div class="flex-1">
                        <?php if (isset($component)) { $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-label','data' => ['for' => 'date','value' => __('Pilih Tanggal')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'date','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Pilih Tanggal'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $attributes = $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $component = $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal18c21970322f9e5c938bc954620c12bb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal18c21970322f9e5c938bc954620c12bb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.text-input','data' => ['id' => 'date','class' => 'block mt-1 w-full','type' => 'date','name' => 'date','value' => $date]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'date','class' => 'block mt-1 w-full','type' => 'date','name' => 'date','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($date)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal18c21970322f9e5c938bc954620c12bb)): ?>
<?php $attributes = $__attributesOriginal18c21970322f9e5c938bc954620c12bb; ?>
<?php unset($__attributesOriginal18c21970322f9e5c938bc954620c12bb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal18c21970322f9e5c938bc954620c12bb)): ?>
<?php $component = $__componentOriginal18c21970322f9e5c938bc954620c12bb; ?>
<?php unset($__componentOriginal18c21970322f9e5c938bc954620c12bb); ?>
<?php endif; ?>
                    </div>
                    <div class="flex gap-2">
                        <button type="submit" class="btn-primary inline-flex items-center px-6 py-2">
                            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z"></path>
                            </svg>
                            Filter
                        </button>
                        <a href="<?php echo e(route('leader.reports.work-time', ['date' => now()->toDateString()])); ?>" class="inline-flex items-center px-6 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors">
                            Hari Ini
                        </a>
                    </div>
                </form>
                <p class="text-xs text-gray-500 mt-2">
                    Menampilkan data untuk: <strong><?php echo e(\Carbon\Carbon::parse($date)->locale('id')->translatedFormat('l, d F Y')); ?></strong>
                </p>
            </div>

            <!-- Summary Cards -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                <div class="bg-white rounded-xl shadow-lg p-6">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm text-gray-500 mb-1">Total Waktu Tim</p>
                            <p class="text-3xl font-bold text-gray-800"><?php echo e(number_format($teamTotalHours, 1)); ?> jam</p>
                            <p class="text-xs text-gray-400 mt-1"><?php echo e($teamTotalMinutes); ?> menit</p>
                        </div>
                        <div class="bg-blue-100 rounded-lg p-3">
                            <svg class="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                            </svg>
                        </div>
                    </div>
                </div>

                <div class="bg-white rounded-xl shadow-lg p-6">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm text-gray-500 mb-1">Total Task Aktif</p>
                            <p class="text-3xl font-bold text-gray-800"><?php echo e($teamTotalTasks); ?></p>
                            <p class="text-xs text-gray-400 mt-1">Task yang dikerjakan</p>
                        </div>
                        <div class="bg-green-100 rounded-lg p-3">
                            <svg class="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"></path>
                            </svg>
                        </div>
                    </div>
                </div>

                <div class="bg-white rounded-xl shadow-lg p-6">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm text-gray-500 mb-1">Anggota Tim</p>
                            <p class="text-3xl font-bold text-gray-800"><?php echo e(count($workTimePerUser)); ?></p>
                            <p class="text-xs text-gray-400 mt-1">User yang aktif</p>
                        </div>
                        <div class="bg-purple-100 rounded-lg p-3">
                            <svg class="w-8 h-8 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.653-.124-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.653.124-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path>
                            </svg>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Work Time Per User -->
            <div class="bg-white rounded-xl shadow-lg p-6 mb-6">
                <div class="flex items-center justify-between mb-6">
                    <h3 class="text-xl font-bold text-gray-800">Waktu Kerja Per User</h3>
                    <div class="bg-blue-50 border border-blue-200 rounded-lg px-4 py-2">
                        <p class="text-xs text-blue-700">
                            <svg class="w-4 h-4 inline mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                            </svg>
                            Data waktu kerja diambil dari update progress yang mengisi "Waktu dari" dan "Waktu sampai"
                        </p>
                    </div>
                </div>
                
                <?php if(count($workTimePerUser) > 0): ?>
                    <div class="space-y-4">
                        <?php $__currentLoopData = $workTimePerUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userId => $userData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="border-2 border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                                <div class="flex items-start justify-between mb-4">
                                    <div class="flex items-center">
                                        <div class="w-12 h-12 rounded-full bg-gradient-to-br from-blue-400 to-purple-500 flex items-center justify-center text-white font-bold text-lg mr-4">
                                            <?php echo e(strtoupper(substr($userData['user']->name, 0, 1))); ?>

                                        </div>
                                        <div>
                                            <h4 class="font-bold text-lg text-gray-800"><?php echo e($userData['user']->name); ?></h4>
                                            <p class="text-sm text-gray-500"><?php echo e($userData['user']->nik ?? 'N/A'); ?></p>
                                            <?php if($userData['user']->position): ?>
                                                <p class="text-xs text-gray-400"><?php echo e($userData['user']->position->name); ?></p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="text-right">
                                        <div class="text-2xl font-bold text-blue-600"><?php echo e($userData['formatted_time']); ?></div>
                                        <div class="text-sm text-gray-500"><?php echo e(number_format($userData['total_hours'], 2)); ?> jam</div>
                                        <div class="text-xs text-gray-400 mt-1"><?php echo e($userData['task_count']); ?> task</div>
                                    </div>
                                </div>

                                <?php if(count($userData['task_details']) > 0): ?>
                                    <div class="mt-4 pt-4 border-t border-gray-200">
                                        <h5 class="font-semibold text-gray-700 mb-3 text-sm">Detail Task:</h5>
                                        <div class="space-y-2">
                                            <?php $__currentLoopData = $userData['task_details']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="bg-gray-50 rounded-lg p-3 flex items-start justify-between">
                                                    <div class="flex-1">
                                                        <p class="font-medium text-sm text-gray-800"><?php echo e($detail['task_item_title']); ?></p>
                                                        <p class="text-xs text-gray-500 mt-1"><?php echo e($detail['task_title']); ?></p>
                                                        <?php if($detail['notes']): ?>
                                                            <p class="text-xs text-gray-400 mt-1 italic"><?php echo e(Str::limit($detail['notes'], 100)); ?></p>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="text-right ml-4">
                                                        <p class="text-sm font-semibold text-gray-700"><?php echo e($detail['formatted_duration']); ?></p>
                                                        <p class="text-xs text-gray-500">
                                                            <?php echo e(\Carbon\Carbon::parse($detail['time_from'])->format('H:i')); ?> - 
                                                            <?php echo e(\Carbon\Carbon::parse($detail['time_to'])->format('H:i')); ?>

                                                        </p>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <div class="mt-4 pt-4 border-t border-gray-200">
                                        <p class="text-sm text-gray-400 italic">Belum ada task yang dikerjakan hari ini</p>
                                        <p class="text-xs text-gray-400 mt-1">
                                            Untuk tracking waktu kerja, user perlu melakukan update progress dengan mengisi kolom "Waktu dari" dan "Waktu sampai" saat update progress task item.
                                        </p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php else: ?>
                    <div class="text-center py-12">
                        <svg class="w-16 h-16 text-gray-400 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                        </svg>
                        <p class="text-gray-500 text-lg font-medium">Tidak ada data waktu kerja</p>
                        <p class="text-gray-400 text-sm mt-1">Belum ada update progress dengan waktu kerja pada tanggal ini</p>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Tasks In Progress -->
            <div class="bg-white rounded-xl shadow-lg p-6">
                <div class="flex items-center justify-between mb-6">
                    <h3 class="text-xl font-bold text-gray-800">Task yang Sedang Berjalan</h3>
                    <div class="bg-yellow-50 border border-yellow-200 rounded-lg px-4 py-2">
                        <p class="text-xs text-yellow-700">
                            <svg class="w-4 h-4 inline mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                            </svg>
                            Menampilkan task yang memiliki detail pekerjaan (task items) di-assign ke anggota tim
                        </p>
                    </div>
                </div>
                
                <?php if($tasksInProgress->count() > 0): ?>
                    <div class="space-y-4">
                        <?php $__currentLoopData = $tasksInProgress; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                // Get all task items assigned to team members (not just in_progress)
                                $activeTaskItems = $task->taskItems->filter(function($item) {
                                    return $item->assignedUser && in_array($item->status, ['pending', 'in_progress']);
                                });
                            ?>
                            
                            <?php if($activeTaskItems->count() > 0): ?>
                                <div class="border-2 border-gray-200 rounded-lg p-4">
                                    <div class="flex items-start justify-between mb-3">
                                        <div class="flex-1">
                                            <h4 class="font-bold text-lg text-gray-800">
                                                <a href="<?php echo e(route('tasks.show', $task)); ?>" class="hover:text-blue-600">
                                                    <?php echo e($task->title); ?>

                                                </a>
                                            </h4>
                                            <?php if($task->project_code): ?>
                                                <p class="text-sm text-gray-500 mt-1">Project: <?php echo e($task->project_code); ?></p>
                                            <?php endif; ?>
                                        </div>
                                        <span class="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-xs font-semibold">
                                            <?php echo e(ucfirst(str_replace('_', ' ', $task->status))); ?>

                                        </span>
                                    </div>

                                    <div class="space-y-2 mt-4">
                                        <?php $__currentLoopData = $activeTaskItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="bg-gray-50 rounded-lg p-3">
                                                <div class="flex items-start justify-between">
                                                    <div class="flex-1">
                                                        <p class="font-medium text-sm text-gray-800"><?php echo e($item->title); ?></p>
                                                        <p class="text-xs text-gray-500 mt-1">
                                                            Assigned to: <span class="font-semibold"><?php echo e($item->assignedUser->name); ?></span>
                                                        </p>
                                                        <div class="mt-2">
                                                            <div class="flex items-center justify-between text-xs text-gray-600 mb-1">
                                                                <span>Status</span>
                                                                <span class="px-2 py-0.5 rounded text-xs font-semibold <?php echo e($item->status === 'in_progress' ? 'bg-blue-100 text-blue-800' : 'bg-yellow-100 text-yellow-800'); ?>">
                                                                    <?php echo e(ucfirst(str_replace('_', ' ', $item->status))); ?>

                                                                </span>
                                                            </div>
                                                            <?php if($item->progress_percentage > 0): ?>
                                                                <div class="flex items-center justify-between text-xs text-gray-600 mb-1 mt-1">
                                                                    <span>Progress</span>
                                                                    <span><?php echo e($item->progress_percentage); ?>%</span>
                                                                </div>
                                                                <div class="w-full bg-gray-200 rounded-full h-2">
                                                                    <div class="bg-blue-600 h-2 rounded-full" style="width: <?php echo e($item->progress_percentage); ?>%"></div>
                                                                </div>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                    <div class="text-right ml-4">
                                                        <?php
                                                            $todayUpdates = $item->updates->filter(function($update) use ($date) {
                                                                return $update->update_date && $update->update_date->format('Y-m-d') == $date && $update->duration_in_minutes;
                                                            });
                                                            $todayMinutes = $todayUpdates->sum(function($update) {
                                                                return $update->duration_in_minutes ?? 0;
                                                            });
                                                        ?>
                                                        <?php if($todayMinutes > 0): ?>
                                                            <p class="text-sm font-semibold text-blue-600">
                                                                <?php echo e(floor($todayMinutes / 60)); ?>j <?php echo e($todayMinutes % 60); ?>m
                                                            </p>
                                                            <p class="text-xs text-gray-500">Hari ini</p>
                                                        <?php else: ?>
                                                            <p class="text-xs text-gray-400">Belum ada</p>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php else: ?>
                    <div class="text-center py-12">
                        <svg class="w-16 h-16 text-gray-400 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"></path>
                        </svg>
                        <p class="text-gray-500 text-lg font-medium">Tidak ada task yang sedang berjalan</p>
                        <p class="text-gray-400 text-sm mt-1">Semua task tim sudah selesai atau belum dimulai</p>
                        <p class="text-gray-400 text-xs mt-2 italic">
                            Catatan: Task yang ditampilkan adalah task yang memiliki detail pekerjaan (task items) yang di-assign ke anggota tim.
                        </p>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Back Button -->
            <div class="mt-6">
                <a href="<?php echo e(route('leader.reports.overview')); ?>" class="inline-flex items-center px-6 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors">
                    <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
                    </svg>
                    Kembali ke Overview
                </a>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\web\job-delegation\resources\views/leader/reports/work-time.blade.php ENDPATH**/ ?>