<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class TaskItem extends Model
{
    protected $fillable = [
        'task_id',
        'title',
        'description',
        'status',
        'progress_percentage',
        'order',
        'assigned_to',
        'due_date',
        'completed_at',
    ];

    protected $casts = [
        'due_date' => 'date',
        'completed_at' => 'datetime',
        'progress_percentage' => 'integer',
        'order' => 'integer',
    ];

    public function task(): BelongsTo
    {
        return $this->belongsTo(Task::class);
    }

    public function assignedUser(): BelongsTo
    {
        return $this->belongsTo(User::class, 'assigned_to');
    }

    public function updates(): HasMany
    {
        return $this->hasMany(TaskItemUpdate::class, 'task_item_id')->latest();
    }

    /**
     * Calculate overall progress of task based on task items
     */
    public static function calculateTaskProgress($taskId)
    {
        $items = self::where('task_id', $taskId)->get();
        
        if ($items->isEmpty()) {
            return 0;
        }

        $totalProgress = $items->sum('progress_percentage');
        return round($totalProgress / $items->count());
    }
}
