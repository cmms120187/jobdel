<?php
    use Illuminate\Support\Facades\Storage;
?>

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                <?php echo e(__('Detail Task')); ?>

            </h2>
            <div class="flex gap-2">
                <a href="<?php echo e(route('tasks.edit', $task)); ?>" class="bg-indigo-500 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded text-sm">
                    Edit
                </a>
                <a href="<?php echo e(route('tasks.index', ['page' => session('tasks_page', 1)])); ?>" class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded text-sm">
                    Kembali
                </a>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <?php if(session('success')): ?>
                <div class="mb-4 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative" role="alert">
                    <span class="block sm:inline"><?php echo e(session('success')); ?></span>
                </div>
            <?php endif; ?>

            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <!-- Task Details -->
                <div class="lg:col-span-2">
                    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
                        <div class="p-6">
                            <h1 class="text-2xl font-bold text-gray-900 mb-4"><?php echo e($task->title); ?></h1>
                            
                            <div class="mb-4">
                                <span class="px-3 py-1 text-sm rounded <?php echo e($task->status === 'completed' ? 'bg-green-100 text-green-800' : ($task->status === 'in_progress' ? 'bg-blue-100 text-blue-800' : 'bg-yellow-100 text-yellow-800')); ?>">
                                    <?php echo e(ucfirst($task->status)); ?>

                                </span>
                                <span class="px-3 py-1 text-sm rounded ml-2 <?php echo e($task->priority === 'high' ? 'bg-red-100 text-red-800' : ($task->priority === 'medium' ? 'bg-yellow-100 text-yellow-800' : 'bg-gray-100 text-gray-800')); ?>">
                                    <?php echo e(ucfirst($task->priority)); ?>

                                </span>
                                <?php if($task->type): ?>
                                    <span class="px-3 py-1 text-sm rounded ml-2 bg-blue-100 text-blue-800">
                                        <?php echo e($task->type); ?>

                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="grid grid-cols-2 gap-4 text-sm mb-4">
                                <?php if($task->room): ?>
                                    <div>
                                        <span class="font-semibold text-gray-700">Room:</span>
                                        <p class="text-gray-600">
                                            <a href="<?php echo e(route('rooms.show', $task->room)); ?>" class="text-blue-600 hover:text-blue-800 font-semibold">
                                                <?php echo e($task->room->room); ?>

                                            </a>
                                            <span class="text-xs text-gray-500">(<?php echo e($task->room->plant); ?>)</span>
                                        </p>
                                    </div>
                                <?php endif; ?>
                                <?php if($task->project_code): ?>
                                    <div>
                                        <span class="font-semibold text-gray-700">Kode Project:</span>
                                        <p class="text-gray-600"><?php echo e($task->project_code); ?></p>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <?php if($task->description): ?>
                                <div class="mb-4">
                                    <h3 class="font-semibold text-gray-700 mb-2">Deskripsi:</h3>
                                    <p class="text-gray-600 whitespace-pre-wrap"><?php echo e($task->description); ?></p>
                                </div>
                            <?php endif; ?>

                            <div class="grid grid-cols-2 gap-4 text-sm">
                                <div>
                                    <span class="font-semibold text-gray-700">User Create:</span>
                                    <p class="text-gray-600">
                                        <?php echo e($task->creator->nik); ?> - <?php echo e($task->creator->name); ?>

                                        <?php if($task->creator->position): ?>
                                            <span class="text-xs text-gray-500">(<?php echo e($task->creator->position->name); ?>)</span>
                                        <?php endif; ?>
                                    </p>
                                </div>
                                <?php if($task->requester): ?>
                                    <div>
                                        <span class="font-semibold text-gray-700">User Request:</span>
                                        <p class="text-gray-600">
                                            <?php echo e($task->requester->nik); ?> - <?php echo e($task->requester->name); ?>

                                            <?php if($task->requester->position): ?>
                                                <span class="text-xs text-gray-500">(<?php echo e($task->requester->position->name); ?>)</span>
                                            <?php endif; ?>
                                        </p>
                                    </div>
                                <?php endif; ?>
                                <?php if($task->add_request): ?>
                                    <div>
                                        <span class="font-semibold text-gray-700">Add Request:</span>
                                        <p class="text-gray-600"><?php echo e($task->add_request); ?></p>
                                    </div>
                                <?php endif; ?>
                                <?php if($task->start_date): ?>
                                    <div>
                                        <span class="font-semibold text-gray-700">Start Date:</span>
                                        <p class="text-gray-600"><?php echo e($task->start_date->format('d M Y')); ?></p>
                                    </div>
                                <?php endif; ?>
                                <div>
                                    <span class="font-semibold text-gray-700">Deadline:</span>
                                    <p class="text-gray-600"><?php echo e($task->due_date ? $task->due_date->format('d M Y') : '-'); ?></p>
                                </div>
                                <?php if($task->approve_level !== null): ?>
                                    <div>
                                        <span class="font-semibold text-gray-700">Approve Level:</span>
                                        <p class="text-gray-600"><?php echo e($task->approve_level); ?></p>
                                    </div>
                                <?php endif; ?>
                                <div>
                                    <span class="font-semibold text-gray-700">Dibuat pada:</span>
                                    <p class="text-gray-600"><?php echo e($task->created_at->format('d M Y H:i')); ?></p>
                                </div>
                                <div>
                                    <span class="font-semibold text-gray-700">Diupdate pada:</span>
                                    <p class="text-gray-600"><?php echo e($task->updated_at->format('d M Y H:i')); ?></p>
                                </div>
                            </div>

                            <!-- File Support -->
                            <?php if($task->file_support_1 || $task->file_support_2): ?>
                                <div class="mt-4 pt-4 border-t">
                                    <h3 class="font-semibold text-gray-700 mb-2">File Support:</h3>
                                    <div class="space-y-2">
                                        <?php if($task->file_support_1): ?>
                                            <div>
                                                <span class="font-semibold text-gray-700">File Support 1:</span>
                                                <a href="<?php echo e(Storage::url($task->file_support_1)); ?>" target="_blank" class="text-blue-600 hover:text-blue-800 ml-2">Download</a>
                                            </div>
                                        <?php endif; ?>
                                        <?php if($task->file_support_2): ?>
                                            <div>
                                                <span class="font-semibold text-gray-700">File Support 2:</span>
                                                <a href="<?php echo e(Storage::url($task->file_support_2)); ?>" target="_blank" class="text-blue-600 hover:text-blue-800 ml-2">Download</a>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Delegations -->
                    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                        <div class="p-6">
                            <div class="flex justify-between items-center mb-4">
                                <h2 class="text-lg font-semibold text-gray-900">Delegasi</h2>
                                <a href="<?php echo e(route('delegations.create', $task)); ?>" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded text-sm">
                                    Tambah Delegasi
                                </a>
                            </div>

                            <?php if($task->delegations->count() > 0): ?>
                                <div class="space-y-4">
                                    <?php $__currentLoopData = $task->delegations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delegation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="border rounded-lg p-4 hover:shadow-md transition-shadow">
                                            <div class="flex justify-between items-start mb-2">
                                                <div class="flex-1">
                                                    <a href="<?php echo e(route('delegations.show', $delegation)); ?>" class="text-blue-600 hover:text-blue-800 font-medium">
                                                        Delegasi ke <?php echo e($delegation->delegatedTo->name); ?>

                                                        <?php if($delegation->delegatedTo->position): ?>
                                                            <span class="text-xs text-gray-500">(<?php echo e($delegation->delegatedTo->position->name); ?>)</span>
                                                        <?php endif; ?>
                                                    </a>
                                                    <p class="text-sm text-gray-500">
                                                        Oleh <?php echo e($delegation->delegatedBy->name); ?>

                                                        <?php if($delegation->delegatedBy->position): ?>
                                                            <span class="text-xs">(<?php echo e($delegation->delegatedBy->position->name); ?>)</span>
                                                        <?php endif; ?>
                                                    </p>
                                                </div>
                                                <span class="px-2 py-1 text-xs rounded <?php echo e($delegation->status === 'completed' ? 'bg-green-100 text-green-800' : ($delegation->status === 'accepted' || $delegation->status === 'in_progress' ? 'bg-blue-100 text-blue-800' : 'bg-yellow-100 text-yellow-800')); ?>">
                                                    <?php echo e(ucfirst($delegation->status)); ?>

                                                </span>
                                            </div>
                                            <div class="mb-3">
                                                <div class="w-full bg-gray-200 rounded-full h-2.5">
                                                    <div class="bg-blue-600 h-2.5 rounded-full transition-all" style="width: <?php echo e($delegation->progress_percentage); ?>%"></div>
                                                </div>
                                                <p class="text-xs text-gray-500 mt-1">Progress: <?php echo e($delegation->progress_percentage); ?>%</p>
                                            </div>
                                            <?php if($delegation->notes): ?>
                                                <p class="text-sm text-gray-600 mb-3"><?php echo e($delegation->notes); ?></p>
                                            <?php endif; ?>

                                            <!-- Progress Updates -->
                                            <?php if($delegation->progressUpdates->count() > 0): ?>
                                                <div class="mt-4 pt-4 border-t border-gray-200">
                                                    <h4 class="text-sm font-semibold text-gray-700 mb-3">Update Progress:</h4>
                                                    <div class="space-y-3">
                                                        <?php $__currentLoopData = $delegation->progressUpdates->sortByDesc('created_at')->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $update): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="bg-gray-50 rounded-lg p-3 border-l-4 border-blue-500">
                                                                <div class="flex items-center justify-between mb-1">
                                                                    <span class="text-sm font-bold text-blue-600"><?php echo e($update->progress_percentage); ?>%</span>
                                                                    <span class="text-xs text-gray-500"><?php echo e($update->created_at->format('d M Y, H:i')); ?></span>
                                                                </div>
                                                                <?php if($update->notes): ?>
                                                                    <p class="text-xs text-gray-700 mt-1"><?php echo e(Str::limit($update->notes, 100)); ?></p>
                                                                <?php endif; ?>
                                                                <?php if($update->attachments && count($update->attachments) > 0): ?>
                                                                    <div class="mt-2 flex gap-2">
                                                                        <?php $__currentLoopData = array_slice($update->attachments, 0, 3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <a href="<?php echo e(Storage::url($attachment)); ?>" target="_blank" class="block">
                                                                                <img src="<?php echo e(Storage::url($attachment)); ?>" alt="Bukti" class="w-12 h-12 object-cover rounded border border-gray-200 hover:border-blue-500 transition-colors">
                                                                            </a>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php if(count($update->attachments) > 3): ?>
                                                                            <div class="w-12 h-12 bg-gray-200 rounded border border-gray-300 flex items-center justify-center">
                                                                                <span class="text-xs text-gray-600">+<?php echo e(count($update->attachments) - 3); ?></span>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                <?php endif; ?>
                                                                <p class="text-xs text-gray-500 mt-1">
                                                                    Oleh: <?php echo e($update->updater->name); ?>

                                                                    <?php if($update->updater->position): ?>
                                                                        <span class="text-gray-400">(<?php echo e($update->updater->position->name); ?>)</span>
                                                                    <?php endif; ?>
                                                                </p>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($delegation->progressUpdates->count() > 3): ?>
                                                            <a href="<?php echo e(route('delegations.show', $delegation)); ?>" class="text-xs text-blue-600 hover:text-blue-800 font-semibold">
                                                                Lihat semua update (<?php echo e($delegation->progressUpdates->count()); ?>)
                                                            </a>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                                <p class="text-xs text-gray-400 mt-2">Belum ada update progress</p>
                                            <?php endif; ?>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php else: ?>
                                <p class="text-gray-500">Belum ada delegasi untuk task ini.</p>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Task History -->
                    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mt-6">
                        <div class="p-6">
                            <h2 class="text-lg font-semibold text-gray-900 mb-4">Riwayat Perubahan Task</h2>
                            
                            <?php if($task->histories->count() > 0): ?>
                                <div class="space-y-4">
                                    <?php $__currentLoopData = $task->histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="border-l-4 border-blue-500 pl-4 py-2 bg-gray-50 rounded-r-lg">
                                            <div class="flex items-start justify-between mb-2">
                                                <div class="flex-1">
                                                    <div class="flex items-center gap-2 mb-1">
                                                        <span class="badge <?php echo e($history->action === 'created' ? 'badge-success' : ($history->action === 'deleted' ? 'badge-danger' : 'badge-info')); ?>">
                                                            <?php echo e(ucfirst($history->action)); ?>

                                                        </span>
                                                        <span class="text-sm text-gray-500">
                                                            <?php echo e($history->created_at->format('d M Y, H:i')); ?>

                                                        </span>
                                                    </div>
                                                    <p class="text-sm text-gray-700">
                                                        Oleh: <span class="font-semibold"><?php echo e($history->updater->name); ?></span>
                                                        <?php if($history->updater->position): ?>
                                                            <span class="text-xs text-gray-500">(<?php echo e($history->updater->position->name); ?>)</span>
                                                        <?php endif; ?>
                                                    </p>
                                                    <?php if($history->notes): ?>
                                                        <p class="text-xs text-gray-600 mt-1"><?php echo e($history->notes); ?></p>
                                                    <?php endif; ?>
                                                    
                                                    <?php if($history->action === 'deleted' && $history->old_values): ?>
                                                        <div class="mt-2 p-2 bg-red-50 border border-red-200 rounded">
                                                            <p class="text-xs text-red-700 font-semibold">Task telah dihapus</p>
                                                            <p class="text-xs text-red-600 mt-1">Data task sebelum dihapus telah disimpan dalam history</p>
                                                        </div>
                                                    <?php endif; ?>
                                                    
                                                    <?php if($history->action === 'updated' && $history->old_values && $history->new_values): ?>
                                                        <div class="mt-2 space-y-1">
                                                            <?php
                                                                $fieldLabels = [
                                                                    'room_id' => 'Room',
                                                                    'project_code' => 'Project Code',
                                                                    'title' => 'Title',
                                                                    'description' => 'Description',
                                                                    'priority' => 'Priority',
                                                                    'type' => 'Type',
                                                                    'status' => 'Status',
                                                                    'due_date' => 'Due Date',
                                                                    'start_date' => 'Start Date',
                                                                    'requested_by' => 'User Request',
                                                                    'add_request' => 'Add Request',
                                                                    'file_support_1' => 'File Support 1',
                                                                    'file_support_2' => 'File Support 2',
                                                                    'approve_level' => 'Approve Level',
                                                                ];
                                                                $oldValuesArray = is_array($history->old_values) ? $history->old_values : [];
                                                                $newValuesArray = is_array($history->new_values) ? $history->new_values : [];
                                                            ?>
                                                            <?php $__currentLoopData = $newValuesArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $newValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if(isset($oldValuesArray[$field]) && $oldValuesArray[$field] != $newValue): ?>
                                                                    <?php
                                                                        // Handle special fields
                                                                        $oldDisplay = $oldValuesArray[$field];
                                                                        $newDisplay = $newValue;
                                                                        
                                                                        // Format dates
                                                                        if (in_array($field, ['due_date', 'start_date']) && $oldDisplay) {
                                                                            try {
                                                                                $oldDisplay = \Carbon\Carbon::parse($oldDisplay)->format('d M Y');
                                                                            } catch (\Exception $e) {
                                                                                // Keep original if parsing fails
                                                                            }
                                                                        }
                                                                        if (in_array($field, ['due_date', 'start_date']) && $newDisplay) {
                                                                            try {
                                                                                $newDisplay = \Carbon\Carbon::parse($newDisplay)->format('d M Y');
                                                                            } catch (\Exception $e) {
                                                                                // Keep original if parsing fails
                                                                            }
                                                                        }
                                                                        
                                                                        // Handle room_id
                                                                        if ($field === 'room_id' && $oldDisplay) {
                                                                            $oldRoom = \App\Models\Room::find($oldDisplay);
                                                                            $oldDisplay = $oldRoom ? $oldRoom->room : $oldDisplay;
                                                                        }
                                                                        if ($field === 'room_id' && $newDisplay) {
                                                                            $newRoom = \App\Models\Room::find($newDisplay);
                                                                            $newDisplay = $newRoom ? $newRoom->room : $newDisplay;
                                                                        }
                                                                        
                                                                        // Handle requested_by
                                                                        if ($field === 'requested_by' && $oldDisplay) {
                                                                            $oldUser = \App\Models\User::find($oldDisplay);
                                                                            $oldDisplay = $oldUser ? $oldUser->name : $oldDisplay;
                                                                        }
                                                                        if ($field === 'requested_by' && $newDisplay) {
                                                                            $newUser = \App\Models\User::find($newDisplay);
                                                                            $newDisplay = $newUser ? $newUser->name : $newDisplay;
                                                                        }
                                                                    ?>
                                                                    <div class="text-xs bg-white p-2 rounded border">
                                                                        <span class="font-semibold text-gray-700"><?php echo e($fieldLabels[$field] ?? ucfirst(str_replace('_', ' ', $field))); ?>:</span>
                                                                        <div class="mt-1">
                                                                            <span class="text-red-600 line-through"><?php echo e($oldDisplay ?? '-'); ?></span>
                                                                            <span class="text-gray-400 mx-2">→</span>
                                                                            <span class="text-green-600 font-semibold"><?php echo e($newDisplay ?? '-'); ?></span>
                                                                        </div>
                                                                    </div>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php else: ?>
                                <p class="text-gray-500 text-center py-4">Belum ada riwayat perubahan.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Sidebar -->
                <div>
                    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                        <div class="p-6">
                            <h3 class="font-semibold text-gray-900 mb-4">Quick Actions</h3>
                            <div class="space-y-2">
                                <a href="<?php echo e(route('delegations.create', $task)); ?>" class="block w-full bg-blue-500 hover:bg-blue-700 text-white text-center font-bold py-2 px-4 rounded">
                                    Delegasikan Task
                                </a>
                                <a href="<?php echo e(route('tasks.edit', $task)); ?>" class="block w-full bg-indigo-500 hover:bg-indigo-700 text-white text-center font-bold py-2 px-4 rounded">
                                    Edit Task
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>

<?php /**PATH C:\xampp\htdocs\training\job-delegation\resources\views/tasks/show.blade.php ENDPATH**/ ?>