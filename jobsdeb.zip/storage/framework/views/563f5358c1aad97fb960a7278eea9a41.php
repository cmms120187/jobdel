<?php
    use Illuminate\Support\Facades\Storage;
?>

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                <?php echo e(__('Detail Task')); ?>

            </h2>
            <div class="flex gap-2">
                <form method="POST" action="<?php echo e(route('tasks.duplicate', $task)); ?>" class="inline">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded text-sm inline-flex items-center">
                        <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"></path>
                        </svg>
                        Duplikat
                    </button>
                </form>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $task)): ?>
                    <a href="<?php echo e(route('tasks.edit', $task)); ?>" class="bg-indigo-500 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded text-sm">
                        Edit
                    </a>
                <?php endif; ?>
                <a href="<?php echo e(route('tasks.index', ['page' => session('tasks_page', 1)])); ?>" class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded text-sm">
                    Kembali
                </a>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <?php if(session('success')): ?>
                <div class="mb-4 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative" role="alert">
                    <span class="block sm:inline"><?php echo e(session('success')); ?></span>
                </div>
            <?php endif; ?>

            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <!-- Task Details -->
                <div class="lg:col-span-2">
                    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
                        <div class="p-6">
                            <h1 class="text-2xl font-bold text-gray-900 mb-4"><?php echo e($task->title); ?></h1>
                            
                            <div class="mb-4">
                                <span class="px-3 py-1 text-sm rounded <?php echo e($task->status === 'completed' ? 'bg-green-100 text-green-800' : ($task->status === 'in_progress' ? 'bg-blue-100 text-blue-800' : 'bg-yellow-100 text-yellow-800')); ?>">
                                    <?php echo e(ucfirst($task->status)); ?>

                                </span>
                                <span class="px-3 py-1 text-sm rounded ml-2 <?php echo e($task->priority === 'high' ? 'bg-red-100 text-red-800' : ($task->priority === 'medium' ? 'bg-yellow-100 text-yellow-800' : 'bg-gray-100 text-gray-800')); ?>">
                                    <?php echo e(ucfirst($task->priority)); ?>

                                </span>
                                <?php if($task->type): ?>
                                    <span class="px-3 py-1 text-sm rounded ml-2 bg-blue-100 text-blue-800">
                                        <?php echo e($task->type); ?>

                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="grid grid-cols-2 gap-4 text-sm mb-4">
                                <?php if($task->room): ?>
                                    <div>
                                        <span class="font-semibold text-gray-700">Room:</span>
                                        <p class="text-gray-600">
                                            <a href="<?php echo e(route('rooms.show', $task->room)); ?>" class="text-blue-600 hover:text-blue-800 font-semibold">
                                                <?php echo e($task->room->room); ?>

                                            </a>
                                            <span class="text-xs text-gray-500">(<?php echo e($task->room->plant); ?>)</span>
                                        </p>
                                    </div>
                                <?php endif; ?>
                                <?php if($task->project_code): ?>
                                    <div>
                                        <span class="font-semibold text-gray-700">Kode Project:</span>
                                        <p class="text-gray-600"><?php echo e($task->project_code); ?></p>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <?php if($task->description): ?>
                                <div class="mb-4">
                                    <h3 class="font-semibold text-gray-700 mb-2">Deskripsi:</h3>
                                    <p class="text-gray-600 whitespace-pre-wrap"><?php echo e($task->description); ?></p>
                                </div>
                            <?php endif; ?>

                            <div class="grid grid-cols-2 gap-4 text-sm">
                                <div>
                                    <span class="font-semibold text-gray-700">User Create:</span>
                                    <p class="text-gray-600">
                                        <?php echo e($task->creator->nik); ?> - <?php echo e($task->creator->name); ?>

                                        <?php if($task->creator->position): ?>
                                            <span class="text-xs text-gray-500">(<?php echo e($task->creator->position->name); ?>)</span>
                                        <?php endif; ?>
                                    </p>
                                </div>
                                <?php if($task->requester): ?>
                                    <div>
                                        <span class="font-semibold text-gray-700">User Request:</span>
                                        <p class="text-gray-600">
                                            <?php echo e($task->requester->nik); ?> - <?php echo e($task->requester->name); ?>

                                            <?php if($task->requester->position): ?>
                                                <span class="text-xs text-gray-500">(<?php echo e($task->requester->position->name); ?>)</span>
                                            <?php endif; ?>
                                        </p>
                                    </div>
                                <?php endif; ?>
                                <?php if($task->add_request): ?>
                                    <div>
                                        <span class="font-semibold text-gray-700">Add Request:</span>
                                        <p class="text-gray-600"><?php echo e($task->add_request); ?></p>
                                    </div>
                                <?php endif; ?>
                                <?php if($task->start_date): ?>
                                    <div>
                                        <span class="font-semibold text-gray-700">Start Date:</span>
                                        <p class="text-gray-600"><?php echo e($task->start_date->format('d M Y')); ?></p>
                                    </div>
                                <?php endif; ?>
                                <div>
                                    <span class="font-semibold text-gray-700">Deadline:</span>
                                    <p class="text-gray-600"><?php echo e($task->due_date ? $task->due_date->format('d M Y') : '-'); ?></p>
                                </div>
                                <?php if($task->approve_level !== null): ?>
                                    <div>
                                        <span class="font-semibold text-gray-700">Approve Level:</span>
                                        <p class="text-gray-600"><?php echo e($task->approve_level); ?></p>
                                    </div>
                                <?php endif; ?>
                                <div>
                                    <span class="font-semibold text-gray-700">Dibuat pada:</span>
                                    <p class="text-gray-600"><?php echo e($task->created_at->format('d M Y H:i')); ?></p>
                                </div>
                                <div>
                                    <span class="font-semibold text-gray-700">Diupdate pada:</span>
                                    <p class="text-gray-600"><?php echo e($task->updated_at->format('d M Y H:i')); ?></p>
                                </div>
                            </div>

                            <!-- File Support -->
                            <?php if($task->file_support_1 || $task->file_support_2): ?>
                                <div class="mt-4 pt-4 border-t">
                                    <h3 class="font-semibold text-gray-700 mb-2">File Support:</h3>
                                    <div class="space-y-2">
                                        <?php if($task->file_support_1): ?>
                                            <div>
                                                <span class="font-semibold text-gray-700">File Support 1:</span>
                                                <a href="<?php echo e(Storage::url($task->file_support_1)); ?>" target="_blank" class="text-blue-600 hover:text-blue-800 ml-2">Download</a>
                                            </div>
                                        <?php endif; ?>
                                        <?php if($task->file_support_2): ?>
                                            <div>
                                                <span class="font-semibold text-gray-700">File Support 2:</span>
                                                <a href="<?php echo e(Storage::url($task->file_support_2)); ?>" target="_blank" class="text-blue-600 hover:text-blue-800 ml-2">Download</a>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Task Items (Detail Pekerjaan) -->
                    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
                        <div class="p-6">
                            <div class="flex justify-between items-center mb-4">
                                <div>
                                    <h2 class="text-lg font-semibold text-gray-900">Detail Pekerjaan</h2>
                                    <?php if($task->taskItems->count() > 0): ?>
                                        <?php
                                            $overallProgress = $task->overall_progress;
                                        ?>
                                        <div class="mt-2">
                                            <div class="flex items-center gap-2">
                                                <div class="w-48 bg-gray-200 rounded-full h-2.5">
                                                    <div class="bg-gradient-to-r from-blue-600 to-indigo-600 h-2.5 rounded-full transition-all" style="width: <?php echo e($overallProgress); ?>%"></div>
                                                </div>
                                                <span class="text-sm font-semibold text-gray-700"><?php echo e($overallProgress); ?>%</span>
                                            </div>
                                            <p class="text-xs text-gray-500 mt-1">Progress keseluruhan berdasarkan detail pekerjaan</p>
                                            <p class="text-xs text-orange-600 mt-1 font-medium">
                                                ⚠️ Progress delegation akan terupdate otomatis berdasarkan detail pekerjaan yang di-assign ke masing-masing user
                                            </p>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <button onclick="document.getElementById('add-task-item-form').classList.toggle('hidden')" class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded text-sm">
                                    + Tambah Detail
                                </button>
                            </div>

                            <!-- Add Task Item Form -->
                            <div id="add-task-item-form" class="hidden mb-6 p-4 bg-gray-50 rounded-lg border border-gray-200">
                                <h3 class="font-semibold text-gray-900 mb-3">Tambah Detail Pekerjaan</h3>
                                <form action="<?php echo e(route('task-items.store', $task)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="space-y-4">
                                        <div>
                                            <label for="title" class="block text-sm font-medium text-gray-700 mb-1">Judul Detail Pekerjaan *</label>
                                            <input type="text" name="title" id="title" required class="w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500" placeholder="Contoh: Setup database, Design UI, dll">
                                            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div>
                                            <label for="description" class="block text-sm font-medium text-gray-700 mb-1">Deskripsi</label>
                                            <textarea name="description" id="description" rows="2" class="w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500" placeholder="Deskripsi detail pekerjaan (opsional)"></textarea>
                                        </div>
                                        <div class="grid grid-cols-2 gap-4">
                                            <div>
                                                <label for="assigned_to" class="block text-sm font-medium text-gray-700 mb-1">Assign To</label>
                                                <select name="assigned_to" id="assigned_to" class="w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                                                    <option value="">Pilih User (Opsional)</option>
                                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($user->id); ?>" <?php echo e($user->id == $currentUser->id ? 'selected' : ''); ?>>
                                                            <?php echo e($user->name); ?> (<?php echo e($user->nik); ?>)
                                                            <?php if($user->position): ?>
                                                                - <?php echo e($user->position->name); ?>

                                                            <?php endif; ?>
                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <p class="text-xs text-gray-500 mt-1">User yang terdaftar dalam delegasi task ini</p>
                                            </div>
                                            <div>
                                                <label for="due_date" class="block text-sm font-medium text-gray-700 mb-1">Due Date</label>
                                                <input type="date" name="due_date" id="due_date" class="w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                                            </div>
                                        </div>
                                        <div class="flex gap-2">
                                            <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded text-sm">
                                                Simpan
                                            </button>
                                            <button type="button" onclick="document.getElementById('add-task-item-form').classList.add('hidden')" class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded text-sm">
                                                Batal
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>

                            <!-- Task Items List -->
                            <?php if($task->taskItems->count() > 0): ?>
                                <div class="space-y-4">
                                    <?php $__currentLoopData = $task->taskItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="border rounded-lg p-4 hover:shadow-md transition-shadow">
                                            <div class="flex justify-between items-start mb-3">
                                                <div class="flex-1">
                                                    <div class="flex items-center gap-2 mb-1">
                                                        <span class="text-xs font-semibold text-gray-500">#<?php echo e($loop->iteration); ?></span>
                                                        <h3 class="font-semibold text-gray-900"><?php echo e($item->title); ?></h3>
                                                        <span class="px-2 py-1 text-xs rounded <?php echo e($item->status === 'completed' ? 'bg-green-100 text-green-800' : ($item->status === 'in_progress' ? 'bg-blue-100 text-blue-800' : 'bg-yellow-100 text-yellow-800')); ?>">
                                                            <?php echo e(ucfirst(str_replace('_', ' ', $item->status))); ?>

                                                        </span>
                                                    </div>
                                                    <?php if($item->description): ?>
                                                        <p class="text-sm text-gray-600 mb-2"><?php echo e($item->description); ?></p>
                                                    <?php endif; ?>
                                                    <div class="flex items-center gap-4 text-xs text-gray-500">
                                                        <?php if($item->assignedUser): ?>
                                                            <span>Assigned: <?php echo e($item->assignedUser->name); ?></span>
                                                        <?php endif; ?>
                                                        <?php if($item->due_date): ?>
                                                            <span>Due: <?php echo e($item->due_date->format('d M Y')); ?></span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <div class="flex gap-2">
                                                    <?php if($item->progress_percentage < 100): ?>
                                                        <button onclick="openProgressModal(<?php echo e($item->id); ?>, <?php echo e($item->progress_percentage); ?>, '<?php echo e($item->title); ?>')" class="bg-blue-500 hover:bg-blue-700 text-white text-xs font-bold py-1.5 px-3 rounded">
                                                            Update Progress
                                                        </button>
                                                    <?php else: ?>
                                                        <button onclick="openProgressModal(<?php echo e($item->id); ?>, <?php echo e($item->progress_percentage); ?>, '<?php echo e($item->title); ?>')" class="bg-green-500 hover:bg-green-700 text-white text-xs font-bold py-1.5 px-3 rounded" title="Progress sudah 100%. Bisa tambah catatan/foto">
                                                            Tambah Catatan/Foto
                                                        </button>
                                                    <?php endif; ?>
                                                    <form action="<?php echo e(route('task-items.destroy', [$task, $item])); ?>" method="POST" onsubmit="return confirm('Hapus detail pekerjaan ini?');" class="inline">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="bg-red-500 hover:bg-red-700 text-white text-xs font-bold py-1.5 px-3 rounded">
                                                            Hapus
                                                        </button>
                                                    </form>
                                                </div>
                                            </div>

                                            <!-- Progress Bar -->
                                            <div class="mb-3">
                                                <div class="w-full bg-gray-200 rounded-full h-3">
                                                    <div class="bg-gradient-to-r from-blue-600 to-indigo-600 h-3 rounded-full transition-all flex items-center justify-end pr-2" style="width: <?php echo e($item->progress_percentage); ?>%">
                                                        <?php if($item->progress_percentage > 15): ?>
                                                            <span class="text-xs font-bold text-white"><?php echo e($item->progress_percentage); ?>%</span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <?php if($item->progress_percentage <= 15): ?>
                                                    <p class="text-xs text-gray-600 mt-1">Progress: <?php echo e($item->progress_percentage); ?>%</p>
                                                <?php endif; ?>
                                            </div>

                                            <!-- Recent Updates -->
                                            <?php if($item->updates->count() > 0): ?>
                                                <div class="mt-3 pt-3 border-t border-gray-200">
                                                    <h4 class="text-xs font-semibold text-gray-700 mb-2">Update Terbaru (<?php echo e($item->updates->count()); ?> update):</h4>
                                                    <div class="space-y-2 max-h-60 overflow-y-auto">
                                                        <?php $__currentLoopData = $item->updates->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $update): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="bg-gray-50 rounded p-3 border-l-2 border-blue-500">
                                                                <div class="flex items-center justify-between mb-1">
                                                                    <div class="flex-1">
                                                                        <span class="text-xs font-bold text-blue-600">
                                                                            <?php if($update->new_progress_percentage !== null): ?>
                                                                                Progress: <?php echo e($update->old_progress_percentage ?? 0); ?>% → <?php echo e($update->new_progress_percentage); ?>%
                                                                            <?php endif; ?>
                                                                            <?php if($update->new_status): ?>
                                                                                | Status: <?php echo e(ucfirst($update->old_status ?? 'pending')); ?> → <?php echo e(ucfirst($update->new_status)); ?>

                                                                            <?php endif; ?>
                                                                    </span>
                                                                    <div class="flex items-center gap-2 mt-1 flex-wrap">
                                                                        <span class="text-xs text-gray-500">
                                                                            📅 <?php echo e($update->update_date ? $update->update_date->format('d M Y') : $update->created_at->format('d M Y')); ?>

                                                                        </span>
                                                                        <?php if($update->time_from || $update->time_to): ?>
                                                                            <span class="text-xs text-gray-400">|</span>
                                                                            <span class="text-xs text-gray-500">
                                                                                ⏰ 
                                                                                <?php if($update->time_from && $update->time_to): ?>
                                                                                    <?php echo e(\Carbon\Carbon::parse($update->time_from)->format('H:i')); ?> - <?php echo e(\Carbon\Carbon::parse($update->time_to)->format('H:i')); ?>

                                                                                <?php elseif($update->time_from): ?>
                                                                                    Mulai: <?php echo e(\Carbon\Carbon::parse($update->time_from)->format('H:i')); ?>

                                                                                <?php elseif($update->time_to): ?>
                                                                                    Selesai: <?php echo e(\Carbon\Carbon::parse($update->time_to)->format('H:i')); ?>

                                                                                <?php endif; ?>
                                                                            </span>
                                                                        <?php else: ?>
                                                                            <span class="text-xs text-gray-400">|</span>
                                                                            <span class="text-xs text-gray-500"><?php echo e($update->created_at->format('H:i')); ?></span>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                </div>
                                                                    <?php if(Auth::user()->position && Auth::user()->position->name === 'Superuser'): ?>
                                                                        <a href="<?php echo e(route('task-items.update.edit', [$task, $item, $update])); ?>" class="text-xs text-indigo-600 hover:text-indigo-800 ml-2" title="Edit Update">
                                                                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path>
                                                                            </svg>
                                                                        </a>
                                                                    <?php endif; ?>
                                                                </div>
                                                                <?php if($update->notes): ?>
                                                                    <p class="text-xs text-gray-700 mt-1"><?php echo e($update->notes); ?></p>
                                                                <?php endif; ?>
                                                                
                                                                <!-- Photo Attachments -->
                                                                <?php if($update->attachments && count($update->attachments) > 0): ?>
                                                                    <div class="mt-2 flex flex-wrap gap-2">
                                                                        <?php $__currentLoopData = $update->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <a href="<?php echo e(Storage::url($attachment)); ?>" target="_blank" class="block">
                                                                                <img src="<?php echo e(Storage::url($attachment)); ?>" alt="Bukti" class="w-16 h-16 object-cover rounded border border-gray-200 hover:border-blue-500 transition-colors cursor-pointer">
                                                                            </a>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </div>
                                                                <?php endif; ?>
                                                                
                                                                <p class="text-xs text-gray-500 mt-2">
                                                                    Oleh: <?php echo e($update->updater->name); ?>

                                                                    <?php if($update->updater->position): ?>
                                                                        <span class="text-gray-400">(<?php echo e($update->updater->position->name); ?>)</span>
                                                                    <?php endif; ?>
                                                                </p>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($item->updates->count() > 5): ?>
                                                            <p class="text-xs text-gray-500 text-center">... dan <?php echo e($item->updates->count() - 5); ?> update lainnya</p>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php else: ?>
                                <p class="text-gray-500 text-center py-4">Belum ada detail pekerjaan. Klik tombol "Tambah Detail" untuk menambahkan.</p>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Delegations -->
                    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                        <div class="p-6">
                            <div class="flex justify-between items-center mb-4">
                                <h2 class="text-lg font-semibold text-gray-900">Delegasi</h2>
                                <a href="<?php echo e(route('delegations.create', $task)); ?>" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded text-sm">
                                    Tambah Delegasi
                                </a>
                            </div>

                            <?php if($task->delegations->count() > 0): ?>
                                <div class="space-y-4">
                                    <?php $__currentLoopData = $task->delegations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delegation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="border rounded-lg p-4 hover:shadow-md transition-shadow">
                                            <div class="flex justify-between items-start mb-2">
                                                <div class="flex-1">
                                                    <a href="<?php echo e(route('delegations.show', $delegation)); ?>" class="text-blue-600 hover:text-blue-800 font-medium">
                                                        Delegasi ke <?php echo e($delegation->delegatedTo->name); ?>

                                                        <?php if($delegation->delegatedTo->position): ?>
                                                            <span class="text-xs text-gray-500">(<?php echo e($delegation->delegatedTo->position->name); ?>)</span>
                                                        <?php endif; ?>
                                                    </a>
                                                    <div class="mt-1">
                                                        <span class="px-2 py-0.5 text-xs rounded <?php echo e($delegation->status === 'completed' ? 'bg-green-100 text-green-800' : ($delegation->status === 'accepted' || $delegation->status === 'in_progress' ? 'bg-blue-100 text-blue-800' : ($delegation->status === 'rejected' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800'))); ?>">
                                                            Status: <?php echo e(ucfirst($delegation->status)); ?>

                                                        </span>
                                                    </div>
                                                    <p class="text-sm text-gray-500">
                                                        Oleh <?php echo e($delegation->delegatedBy->name); ?>

                                                        <?php if($delegation->delegatedBy->position): ?>
                                                            <span class="text-xs">(<?php echo e($delegation->delegatedBy->position->name); ?>)</span>
                                                        <?php endif; ?>
                                                    </p>
                                                </div>
                                                <span class="px-2 py-1 text-xs rounded <?php echo e($delegation->status === 'completed' ? 'bg-green-100 text-green-800' : ($delegation->status === 'accepted' || $delegation->status === 'in_progress' ? 'bg-blue-100 text-blue-800' : 'bg-yellow-100 text-yellow-800')); ?>">
                                                    <?php echo e(ucfirst($delegation->status)); ?>

                                                </span>
                                            </div>
                                            <div class="mb-3">
                                                <div class="w-full bg-gray-200 rounded-full h-2.5">
                                                    <div class="bg-blue-600 h-2.5 rounded-full transition-all" style="width: <?php echo e($delegation->progress_percentage); ?>%"></div>
                                                </div>
                                                <p class="text-xs text-gray-500 mt-1">Progress: <?php echo e($delegation->progress_percentage); ?>%</p>
                                            </div>
                                            <?php if($delegation->notes): ?>
                                                <p class="text-sm text-gray-600 mb-3"><?php echo e($delegation->notes); ?></p>
                                            <?php endif; ?>

                                            <!-- Progress Updates -->
                                            <?php if($delegation->progressUpdates->count() > 0): ?>
                                                <div class="mt-4 pt-4 border-t border-gray-200">
                                                    <h4 class="text-sm font-semibold text-gray-700 mb-3">Update Progress:</h4>
                                                    <div class="space-y-3">
                                                        <?php $__currentLoopData = $delegation->progressUpdates->sortByDesc('created_at')->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $update): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="bg-gray-50 rounded-lg p-3 border-l-4 border-blue-500">
                                                                <div class="flex items-center justify-between mb-1">
                                                                    <span class="text-sm font-bold text-blue-600"><?php echo e($update->progress_percentage); ?>%</span>
                                                                    <span class="text-xs text-gray-500"><?php echo e($update->created_at->format('d M Y, H:i')); ?></span>
                                                                </div>
                                                                <?php if($update->notes): ?>
                                                                    <p class="text-xs text-gray-700 mt-1"><?php echo e(Str::limit($update->notes, 100)); ?></p>
                                                                <?php endif; ?>
                                                                <?php if($update->attachments && count($update->attachments) > 0): ?>
                                                                    <div class="mt-2 flex gap-2">
                                                                        <?php $__currentLoopData = array_slice($update->attachments, 0, 3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <a href="<?php echo e(Storage::url($attachment)); ?>" target="_blank" class="block">
                                                                                <img src="<?php echo e(Storage::url($attachment)); ?>" alt="Bukti" class="w-12 h-12 object-cover rounded border border-gray-200 hover:border-blue-500 transition-colors">
                                                                            </a>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php if(count($update->attachments) > 3): ?>
                                                                            <div class="w-12 h-12 bg-gray-200 rounded border border-gray-300 flex items-center justify-center">
                                                                                <span class="text-xs text-gray-600">+<?php echo e(count($update->attachments) - 3); ?></span>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                <?php endif; ?>
                                                                <p class="text-xs text-gray-500 mt-1">
                                                                    Oleh: <?php echo e($update->updater->name); ?>

                                                                    <?php if($update->updater->position): ?>
                                                                        <span class="text-gray-400">(<?php echo e($update->updater->position->name); ?>)</span>
                                                                    <?php endif; ?>
                                                                </p>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($delegation->progressUpdates->count() > 3): ?>
                                                            <a href="<?php echo e(route('delegations.show', $delegation)); ?>" class="text-xs text-blue-600 hover:text-blue-800 font-semibold">
                                                                Lihat semua update (<?php echo e($delegation->progressUpdates->count()); ?>)
                                                            </a>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                                <p class="text-xs text-gray-400 mt-2">Belum ada update progress</p>
                                            <?php endif; ?>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php else: ?>
                                <p class="text-gray-500">Belum ada delegasi untuk task ini.</p>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Task History -->
                    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mt-6">
                        <div class="p-6">
                            <h2 class="text-lg font-semibold text-gray-900 mb-4">Riwayat Perubahan Task</h2>
                            
                            <?php if($task->histories->count() > 0): ?>
                                <div class="space-y-4">
                                    <?php $__currentLoopData = $task->histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="border-l-4 border-blue-500 pl-4 py-2 bg-gray-50 rounded-r-lg">
                                            <div class="flex items-start justify-between mb-2">
                                                <div class="flex-1">
                                                    <div class="flex items-center gap-2 mb-1">
                                                        <span class="badge <?php echo e($history->action === 'created' ? 'badge-success' : ($history->action === 'deleted' ? 'badge-danger' : 'badge-info')); ?>">
                                                            <?php echo e(ucfirst($history->action)); ?>

                                                        </span>
                                                        <span class="text-sm text-gray-500">
                                                            <?php echo e($history->created_at->format('d M Y, H:i')); ?>

                                                        </span>
                                                    </div>
                                                    <p class="text-sm text-gray-700">
                                                        Oleh: <span class="font-semibold"><?php echo e($history->updater->name); ?></span>
                                                        <?php if($history->updater->position): ?>
                                                            <span class="text-xs text-gray-500">(<?php echo e($history->updater->position->name); ?>)</span>
                                                        <?php endif; ?>
                                                    </p>
                                                    <?php if($history->notes): ?>
                                                        <p class="text-xs text-gray-600 mt-1"><?php echo e($history->notes); ?></p>
                                                    <?php endif; ?>
                                                    
                                                    <?php if($history->action === 'deleted' && $history->old_values): ?>
                                                        <div class="mt-2 p-2 bg-red-50 border border-red-200 rounded">
                                                            <p class="text-xs text-red-700 font-semibold">Task telah dihapus</p>
                                                            <p class="text-xs text-red-600 mt-1">Data task sebelum dihapus telah disimpan dalam history</p>
                                                        </div>
                                                    <?php endif; ?>
                                                    
                                                    <?php if($history->action === 'updated' && $history->old_values && $history->new_values): ?>
                                                        <div class="mt-2 space-y-1">
                                                            <?php
                                                                $fieldLabels = [
                                                                    'room_id' => 'Room',
                                                                    'project_code' => 'Project Code',
                                                                    'title' => 'Title',
                                                                    'description' => 'Description',
                                                                    'priority' => 'Priority',
                                                                    'type' => 'Type',
                                                                    'status' => 'Status',
                                                                    'due_date' => 'Due Date',
                                                                    'start_date' => 'Start Date',
                                                                    'requested_by' => 'User Request',
                                                                    'add_request' => 'Add Request',
                                                                    'file_support_1' => 'File Support 1',
                                                                    'file_support_2' => 'File Support 2',
                                                                    'approve_level' => 'Approve Level',
                                                                ];
                                                                $oldValuesArray = is_array($history->old_values) ? $history->old_values : [];
                                                                $newValuesArray = is_array($history->new_values) ? $history->new_values : [];
                                                            ?>
                                                            <?php $__currentLoopData = $newValuesArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $newValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if(isset($oldValuesArray[$field]) && $oldValuesArray[$field] != $newValue): ?>
                                                                    <?php
                                                                        // Handle special fields
                                                                        $oldDisplay = $oldValuesArray[$field];
                                                                        $newDisplay = $newValue;
                                                                        
                                                                        // Format dates
                                                                        if (in_array($field, ['due_date', 'start_date']) && $oldDisplay) {
                                                                            try {
                                                                                $oldDisplay = \Carbon\Carbon::parse($oldDisplay)->format('d M Y');
                                                                            } catch (\Exception $e) {
                                                                                // Keep original if parsing fails
                                                                            }
                                                                        }
                                                                        if (in_array($field, ['due_date', 'start_date']) && $newDisplay) {
                                                                            try {
                                                                                $newDisplay = \Carbon\Carbon::parse($newDisplay)->format('d M Y');
                                                                            } catch (\Exception $e) {
                                                                                // Keep original if parsing fails
                                                                            }
                                                                        }
                                                                        
                                                                        // Handle room_id
                                                                        if ($field === 'room_id' && $oldDisplay) {
                                                                            $oldRoom = \App\Models\Room::find($oldDisplay);
                                                                            $oldDisplay = $oldRoom ? $oldRoom->room : $oldDisplay;
                                                                        }
                                                                        if ($field === 'room_id' && $newDisplay) {
                                                                            $newRoom = \App\Models\Room::find($newDisplay);
                                                                            $newDisplay = $newRoom ? $newRoom->room : $newDisplay;
                                                                        }
                                                                        
                                                                        // Handle requested_by
                                                                        if ($field === 'requested_by' && $oldDisplay) {
                                                                            $oldUser = \App\Models\User::find($oldDisplay);
                                                                            $oldDisplay = $oldUser ? $oldUser->name : $oldDisplay;
                                                                        }
                                                                        if ($field === 'requested_by' && $newDisplay) {
                                                                            $newUser = \App\Models\User::find($newDisplay);
                                                                            $newDisplay = $newUser ? $newUser->name : $newDisplay;
                                                                        }
                                                                    ?>
                                                                    <div class="text-xs bg-white p-2 rounded border">
                                                                        <span class="font-semibold text-gray-700"><?php echo e($fieldLabels[$field] ?? ucfirst(str_replace('_', ' ', $field))); ?>:</span>
                                                                        <div class="mt-1">
                                                                            <span class="text-red-600 line-through"><?php echo e($oldDisplay ?? '-'); ?></span>
                                                                            <span class="text-gray-400 mx-2">→</span>
                                                                            <span class="text-green-600 font-semibold"><?php echo e($newDisplay ?? '-'); ?></span>
                                                                        </div>
                                                                    </div>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php else: ?>
                                <p class="text-gray-500 text-center py-4">Belum ada riwayat perubahan.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Sidebar -->
                <div>
                    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                        <div class="p-6">
                            <h3 class="font-semibold text-gray-900 mb-4">Quick Actions</h3>
                            <div class="space-y-2">
                                <form method="POST" action="<?php echo e(route('tasks.duplicate', $task)); ?>" class="w-full">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="w-full bg-green-500 hover:bg-green-700 text-white text-center font-bold py-2 px-4 rounded inline-flex items-center justify-center">
                                        <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"></path>
                                        </svg>
                                        Duplikat Task
                                    </button>
                                </form>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', [App\Models\Delegation::class, $task])): ?>
                                    <a href="<?php echo e(route('delegations.create', $task)); ?>" class="block w-full bg-blue-500 hover:bg-blue-700 text-white text-center font-bold py-2 px-4 rounded">
                                        Delegasikan Task
                                    </a>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $task)): ?>
                                    <a href="<?php echo e(route('tasks.edit', $task)); ?>" class="block w-full bg-indigo-500 hover:bg-indigo-700 text-white text-center font-bold py-2 px-4 rounded">
                                        Edit Task
                                    </a>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $task)): ?>
                                    <form method="POST" action="<?php echo e(route('tasks.destroy', $task)); ?>" onsubmit="return confirm('Apakah Anda yakin ingin menghapus task ini?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="w-full bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded">
                                            Hapus Task
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Progress Update Modal -->
    <div id="progressModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden items-center justify-center z-50 overflow-y-auto">
        <div class="bg-white rounded-lg shadow-xl max-w-md w-full mx-4 my-8">
            <div class="p-6">
                <h3 class="text-lg font-semibold text-gray-900 mb-4">Update Progress</h3>
                <p class="text-sm text-gray-600 mb-4" id="modal-item-title"></p>
                
                <form id="progressForm" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="space-y-4">
                        <div>
                            <label for="progress_percentage" class="block text-sm font-medium text-gray-700 mb-2">Progress (0-100%)</label>
                            <input type="number" name="progress_percentage" id="progress_percentage" min="0" max="100" required class="w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                            <div class="mt-2">
                                <input type="range" id="progress_range" min="0" max="100" class="w-full" oninput="document.getElementById('progress_percentage').value = this.value">
                            </div>
                            <p class="text-xs text-gray-500 mt-1">Catatan: Progress bisa diupdate berkali-kali sampai mencapai 100%</p>
                        </div>
                        <div>
                            <label for="update_date" class="block text-sm font-medium text-gray-700 mb-1">Tanggal Update *</label>
                            <input type="date" name="update_date" id="update_date" required class="w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                            <p class="text-xs text-gray-500 mt-1">Pilih tanggal update progress (default: hari ini)</p>
                        </div>
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label for="time_from" class="block text-sm font-medium text-gray-700 mb-1">Waktu Mulai</label>
                                <input type="time" name="time_from" id="time_from" class="w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                                <p class="text-xs text-gray-500 mt-1">Jam mulai bekerja (opsional)</p>
                            </div>
                            <div>
                                <label for="time_to" class="block text-sm font-medium text-gray-700 mb-1">Waktu Selesai</label>
                                <input type="time" name="time_to" id="time_to" class="w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                                <p class="text-xs text-gray-500 mt-1">Jam selesai bekerja (opsional)</p>
                            </div>
                        </div>
                        <div>
                            <label for="notes" class="block text-sm font-medium text-gray-700 mb-1">Catatan</label>
                            <textarea name="notes" id="notes" rows="3" class="w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500" placeholder="Tambahkan catatan update (opsional)"></textarea>
                        </div>
                        
                        <!-- Photo Upload Section -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Foto Bukti (Opsional)</label>
                            <div class="space-y-2">
                                <!-- File Input (Hidden) -->
                                <input type="file" id="photo-input" name="photos[]" accept="image/*" multiple class="hidden" onchange="handlePhotoSelect(event)">
                                
                                <!-- Upload Button -->
                                <button type="button" onclick="document.getElementById('photo-input').click()" class="w-full bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded text-sm mb-2">
                                    📷 Upload Foto
                                </button>
                                
                                <!-- Camera Button (Mobile) -->
                                <button type="button" onclick="openCamera()" class="w-full bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded text-sm">
                                    📸 Ambil Foto dari Kamera
                                </button>
                                
                                <!-- Camera Input (Hidden) -->
                                <input type="file" id="camera-input" name="photos[]" accept="image/*" capture="environment" multiple class="hidden" onchange="handlePhotoSelect(event)">
                                
                                <!-- Preview Images -->
                                <div id="photo-preview" class="grid grid-cols-2 gap-2 mt-3"></div>
                                <p class="text-xs text-gray-500 mt-1">Maksimal 5MB per foto. Bisa upload multiple foto.</p>
                            </div>
                        </div>
                        
                        <div class="flex gap-2 justify-end pt-4 border-t">
                            <button type="button" onclick="closeProgressModal()" class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded text-sm">
                                Batal
                            </button>
                            <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded text-sm">
                                Simpan Update
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        let selectedPhotos = [];

        function openProgressModal(itemId, currentProgress, itemTitle) {
            const modal = document.getElementById('progressModal');
            const form = document.getElementById('progressForm');
            const progressInput = document.getElementById('progress_percentage');
            const progressRange = document.getElementById('progress_range');
            const titleElement = document.getElementById('modal-item-title');
            const photoPreview = document.getElementById('photo-preview');
            
            // Reset form
            titleElement.textContent = itemTitle;
            progressInput.value = currentProgress;
            progressRange.value = currentProgress;
            document.getElementById('notes').value = '';
            // Set default tanggal hari ini
            const today = new Date().toISOString().split('T')[0];
            document.getElementById('update_date').value = today;
            document.getElementById('photo-input').value = '';
            document.getElementById('camera-input').value = '';
            photoPreview.innerHTML = '';
            selectedPhotos = [];
            
            form.action = '<?php echo e(route("task-items.update-progress", [$task, ":itemId"])); ?>'.replace(':itemId', itemId);
            
            modal.classList.remove('hidden');
            modal.classList.add('flex');
        }

        function closeProgressModal() {
            const modal = document.getElementById('progressModal');
            const photoPreview = document.getElementById('photo-preview');
            
            // Reset
            photoPreview.innerHTML = '';
            selectedPhotos = [];
            document.getElementById('photo-input').value = '';
            document.getElementById('camera-input').value = '';
            
            modal.classList.add('hidden');
            modal.classList.remove('flex');
        }

        function openCamera() {
            // Try to open camera directly
            document.getElementById('camera-input').click();
        }

        function handlePhotoSelect(event) {
            const files = Array.from(event.target.files);
            const photoPreview = document.getElementById('photo-preview');
            
            files.forEach(file => {
                if (file.type.startsWith('image/')) {
                    selectedPhotos.push(file);
                    
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        const div = document.createElement('div');
                        div.className = 'relative';
                        div.innerHTML = `
                            <img src="${e.target.result}" alt="Preview" class="w-full h-24 object-cover rounded border border-gray-300">
                            <button type="button" onclick="removePhoto(this)" class="absolute top-0 right-0 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs">×</button>
                        `;
                        photoPreview.appendChild(div);
                    };
                    reader.readAsDataURL(file);
                }
            });
        }

        function removePhoto(button) {
            const div = button.parentElement;
            const index = Array.from(div.parentElement.children).indexOf(div);
            selectedPhotos.splice(index, 1);
            div.remove();
        }

        // Close modal when clicking outside
        document.getElementById('progressModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeProgressModal();
            }
        });

        // Sync range input with number input
        document.getElementById('progress_percentage').addEventListener('input', function() {
            document.getElementById('progress_range').value = this.value;
        });

        document.getElementById('progress_range').addEventListener('input', function() {
            document.getElementById('progress_percentage').value = this.value;
        });

        // Handle form submission with multiple file inputs
        document.getElementById('progressForm').addEventListener('submit', function(e) {
            // Merge files from both inputs if needed
            const photoInput = document.getElementById('photo-input');
            const cameraInput = document.getElementById('camera-input');
            
            if (photoInput.files.length > 0 && cameraInput.files.length > 0) {
                // Create a new FileList or DataTransfer to combine files
                const dt = new DataTransfer();
                Array.from(photoInput.files).forEach(file => dt.items.add(file));
                Array.from(cameraInput.files).forEach(file => dt.items.add(file));
                photoInput.files = dt.files;
            }
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>

<?php /**PATH C:\xampp\htdocs\web\job-delegation\resources\views/tasks/show.blade.php ENDPATH**/ ?>